todo_list = []
Khóa (Key),Kiểu Dữ liệu (Type),Mô tả
'tieu_de',String,"Nội dung chính của công việc (Ví dụ: ""Học Python cơ bản"")."
'trang_thai',Boolean,"Trạng thái hoàn thành (True là Đã hoàn thành, False là Chưa hoàn thành)."
'uu_tien',String hoặc Integer,"Mức độ ưu tiên (Ví dụ: ""Cao"", ""Trung bình"", ""Thấp"" hoặc 1, 2, 3)."
'thoi_han',String,"Ngày/giờ cần hoàn thành (Ví dụ: ""2025-12-31"" hoặc ""Ngày mai"")."
todo_list = [
    {
        'tieu_de': 'Soạn email cho giảng viên ITA101',
        'trang_thai': True,
        'uu_tien': 'Cao',
        'thoi_han': 'Hôm nay'
    },
    {
        'tieu_de': 'Viết chương trình To-do list bằng Python',
        'trang_thai': False,
        'uu_tien': 'Cao',
        'thoi_han': 'Thứ 6 tuần này'
    },
    {
        'tieu_de': 'Mua sách lập trình nâng cao',
        'trang_thai': False,
        'uu_tien': 'Thấp',
        'thoi_han': 'Cuối tuần'
    }
]
# Danh sách toàn cục để lưu trữ dữ liệu To-do list
todo_list = []
def hien_thi_danh_sach(danh_sach):
    """In ra toàn bộ danh sách công việc."""
    print("\n--- DANH SÁCH CÔNG VIỆC CỦA BẠN ---")
    if not danh_sach:
        print("Danh sách hiện đang trống. Hãy thêm công việc mới!")
        return

    for i, cong_viec in enumerate(danh_sach):
        # Xác định ký hiệu trạng thái
        trang_thai_text = "[X]" if cong_viec['trang_thai'] else "[ ]"
        
        # Format đầu ra
        print(f"[{i + 1}] {trang_thai_text} {cong_viec['tieu_de']}")
        print(f"    - Ưu tiên: {cong_viec['uu_tien']} | Hạn: {cong_viec['thoi_han']}")
    print("----------------------------------------")
def them_cong_viec(danh_sach):
    """Thêm một công việc mới vào danh sách."""
    tieu_de = input("Nhập tiêu đề công việc: ")
    uu_tien = input("Nhập mức độ ưu tiên (Cao/Trung bình/Thấp): ")
    thoi_han = input("Nhập thời hạn (Ví dụ: Hôm nay, T6 tuần này): ")

    # Tạo Dictionary công việc mới
    cong_viec_moi = {
        'tieu_de': tieu_de,
        'trang_thai': False,  # Mặc định là Chưa hoàn thành
        'uu_tien': uu_tien,
        'thoi_han': thoi_han
    }
    
    danh_sach.append(cong_viec_moi)
    print(f"✅ Đã thêm công việc: '{tieu_de}'")
def danh_dau_hoan_thanh(danh_sach):
    """Đánh dấu một công việc là đã hoàn thành."""
    hien_thi_danh_sach(danh_sach)
    if not danh_sach:
        return
        
    try:
        chi_muc = int(input("Nhập SỐ THỨ TỰ công việc muốn hoàn thành: ")) - 1
        
        if 0 <= chi_muc < len(danh_sach):
            # Cập nhật trạng thái
            danh_sach[chi_muc]['trang_thai'] = True
            print(f"🎉 Công việc '{danh_sach[chi_muc]['tieu_de']}' đã được đánh dấu HOÀN THÀNH.")
        else:
            print("❌ Số thứ tự không hợp lệ.")
            
    except ValueError:
        print("❌ Vui lòng nhập một số.")
def xoa_cong_viec(danh_sach):
    """Xóa một công việc khỏi danh sách."""
    hien_thi_danh_sach(danh_sach)
    if not danh_sach:
        return
        
    try:
        chi_muc = int(input("Nhập SỐ THỨ TỰ công việc muốn xóa: ")) - 1
        
        if 0 <= chi_muc < len(danh_sach):
            # Xóa công việc khỏi danh sách
            cong_viec_da_xoa = danh_sach.pop(chi_muc)
            print(f"🗑️ Đã xóa công việc: '{cong_viec_da_xoa['tieu_de']}'.")
        else:
            print("❌ Số thứ tự không hợp lệ.")
            
    except ValueError:
        print("❌ Vui lòng nhập một số.")
# Danh sách toàn cục để lưu trữ dữ liệu To-do list
# Khởi tạo với một vài công việc mẫu
todo_list = [
    {
        'tieu_de': 'Học hàm và vòng lặp Python',
        'trang_thai': False,
        'uu_tien': 'Cao',
        'thoi_han': 'Cuối tuần'
    },
    {
        'tieu_de': 'Tập thể dục 30 phút',
        'trang_thai': True,
        'uu_tien': 'Trung bình',
        'thoi_han': 'Mỗi ngày'
    }
]

def hien_thi_danh_sach(danh_sach):
    """In ra toàn bộ danh sách công việc."""
    print("\n--- DANH SÁCH CÔNG VIỆC CỦA BẠN ---")
    if not danh_sach:
        print("Danh sách hiện đang trống. Hãy thêm công việc mới!")
        return

    # Sắp xếp theo ưu tiên để hiển thị trực quan hơn (tùy chọn nâng cao)
    # Tuy nhiên, ở đây ta sẽ giữ nguyên thứ tự nhập vào để dễ dàng thao tác bằng chỉ mục
    
    for i, cong_viec in enumerate(danh_sach):
        # Xác định ký hiệu trạng thái
        trang_thai_text = "[X]" if cong_viec['trang_thai'] else "[ ]"
        
        # Format đầu ra
        print(f"[{i + 1}] {trang_thai_text} {cong_viec['tieu_de']}")
        print(f"    - Ưu tiên: {cong_viec['uu_tien']} | Hạn: {cong_viec['thoi_han']}")
    print("----------------------------------------")

def them_cong_viec(danh_sach):
    """Thêm một công việc mới vào danh sách."""
    tieu_de = input("Nhập tiêu đề công việc: ")
    uu_tien = input("Nhập mức độ ưu tiên (Cao/Trung bình/Thấp): ")
    thoi_han = input("Nhập thời hạn (Ví dụ: Hôm nay, T6 tuần này): ")

    # Tạo Dictionary công việc mới
    cong_viec_moi = {
        'tieu_de': tieu_de,
        'trang_thai': False,
        'uu_tien': uu_tien,
        'thoi_han': thoi_han
    }
    
    danh_sach.append(cong_viec_moi)
    print(f"✅ Đã thêm công việc: '{tieu_de}'")

def danh_dau_hoan_thanh(danh_sach):
    """Đánh dấu một công việc là đã hoàn thành."""
    hien_thi_danh_sach(danh_sach)
    if not danh_sach:
        return
        
    try:
        chi_muc = int(input("Nhập SỐ THỨ TỰ công việc muốn hoàn thành: ")) - 1
        
        if 0 <= chi_muc < len(danh_sach):
            # Cập nhật trạng thái
            danh_sach[chi_muc]['trang_thai'] = True
            print(f"🎉 Công việc '{danh_sach[chi_muc]['tieu_de']}' đã được đánh dấu HOÀN THÀNH.")
        else:
            print("❌ Số thứ tự không hợp lệ.")
            
    except ValueError:
        print("❌ Vui lòng nhập một số.")

def xoa_cong_viec(danh_sach):
    """Xóa một công việc khỏi danh sách."""
    hien_thi_danh_sach(danh_sach)
    if not danh_sach:
        return
        
    try:
        chi_muc = int(input("Nhập SỐ THỨ TỰ công việc muốn xóa: ")) - 1
        
        if 0 <= chi_muc < len(danh_sach):
            # Xóa công việc khỏi danh sách
            cong_viec_da_xoa = danh_sach.pop(chi_muc)
            print(f"🗑️ Đã xóa công việc: '{cong_viec_da_xoa['tieu_de']}'.")
        else:
            print("❌ Số thứ tự không hợp lệ.")
            
    except ValueError:
        print("❌ Vui lòng nhập một số.")

# --- VÒNG LẶP CHÍNH CỦA CHƯƠNG TRÌNH ---
def main():
    """Hàm chính điều khiển luồng chương trình."""
    print("🌟 CHÀO MỪNG ĐẾN VỚI ỨNG DỤNG TO-DO LIST CƠ BẢN 🌟")
    
    while True:
        print("\n--- MENU CHỨC NĂNG ---")
        print("1. Xem danh sách công việc")
        print("2. Thêm công việc mới")
        print("3. Đánh dấu hoàn thành")
        print("4. Xóa công việc")
        print("5. Thoát chương trình")
        
        lua_chon = input("Chọn chức năng (1-5): ")
        
        if lua_chon == '1':
            hien_thi_danh_sach(todo_list)
        elif lua_chon == '2':
            them_cong_viec(todo_list)
        elif lua_chon == '3':
            danh_dau_hoan_thanh(todo_list)
        elif lua_chon == '4':
            xoa_cong_viec(todo_list)
        elif lua_chon == '5':
            print("👋 Cảm ơn bạn đã sử dụng chương trình. Tạm biệt!")
            break
        else:
            print("❌ Lựa chọn không hợp lệ. Vui lòng chọn lại từ 1 đến 5.")

# Chạy chương trình
if __name__ == "__main__":
    main()